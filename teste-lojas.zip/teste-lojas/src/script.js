const API = "https://script.google.com/macros/s/AKfycbxUd531Z1Ew1M0eXpvKm0EY6cEcIbE7XeoSSkzteMz4TEBu_ekBa2QJR2ttF7Er4I2UZg/exec";

let produtos = [];
let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
let categoriaAtual = "todas";

function el(id){
  return document.getElementById(id);
}

/* ========================= */
/* 🚀 INICIALIZAÇÃO */
/* ========================= */

document.addEventListener("DOMContentLoaded", () => {
  carregar();

  // botão voltar topo
  const btnTopo = document.querySelector(".voltar-topo");
  if (btnTopo) {
    btnTopo.addEventListener("click", () => {
      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    });
  }

  // busca automática
  if(el("busca")){
    el("busca").addEventListener("input", () => {
      setTimeout(buscar, 300);
    });
  }
});

/* ========================= */
/* 📦 PRODUTOS */
/* ========================= */

async function carregar(){
  try {
    const res = await fetch(API);
    produtos = await res.json();

    gerarFiltros();
    render(produtos);
gerarMaisVendidos();
    atualizar();
  } catch(e){
    console.error("Erro ao carregar produtos:", e);
  }
}

function formatar(v){
  return Number(v || 0).toLocaleString("pt-BR", {
    style:"currency",
    currency:"BRL"
  });
}

function render(lista){
  const container = el("produtos");
  if(!container) return;

  container.innerHTML = "";

  lista.forEach(p=>{
    let qtd = carrinho.find(i=>i.codigo == p.codigo)?.qtd || 0;

    container.innerHTML += `
      <div class="card">
        <img src="${p.imagem || 'https://via.placeholder.com/100'}">
        <b>${p.nome}</b>
        <span>${formatar(p.preco)}</span>

        <div class="controle">
          <button onclick="menos('${p.codigo}')">-</button>
          <span>${qtd}</span>
          <button onclick="mais('${p.codigo}')">+</button>
        </div>
      </div>
    `;
  });
}

/* ========================= */
/* 🛒 CARRINHO */
/* ========================= */

function mais(codigo){
  let produto = produtos.find(p=>p.codigo == codigo);
  let item = carrinho.find(p=>p.codigo == codigo);

  if(item) item.qtd++;
  else if(produto) carrinho.push({...produto, qtd:1});

  atualizar();
}

function menos(codigo){
  let item = carrinho.find(p=>p.codigo == codigo);
  if(!item) return;

  item.qtd--;

  if(item.qtd <= 0){
    carrinho = carrinho.filter(p=>p.codigo != codigo);
  }

  atualizar();
}

function atualizar(){
  let total = 0;
  let qtdTotal = 0;
  let html = "";

  carrinho.forEach(p=>{
    total += p.preco * p.qtd;
    qtdTotal += p.qtd;

    html += `
      <div class="item">
        <div style="flex:1;">
          ${p.nome}<br>
          <small>${formatar(p.preco)}</small>
        </div>

        <div style="display:flex; gap:4px;">
          <button class="qtd-btn" onclick="menos('${p.codigo}')">-</button>
          <span>${p.qtd}</span>
          <button class="qtd-btn" onclick="mais('${p.codigo}')">+</button>
        </div>
      </div>
    `;
  });

  if(el("itens")) el("itens").innerHTML = html;
  if(el("total")) el("total").innerText = formatar(total);
  if(el("totalTop")) el("totalTop").innerText = formatar(total);
  if(el("qtd")) el("qtd").innerText = `(${qtdTotal})`;
  if(el("qtdTop")) el("qtdTop").innerText = `(${qtdTotal})`;

  localStorage.setItem("carrinho", JSON.stringify(carrinho));

  buscar();
}

/* ========================= */
/* 🔍 BUSCA */
/* ========================= */

function buscar(){
  let termo = el("busca")?.value.toLowerCase() || "";

  let lista = produtos.filter(p =>
    (categoriaAtual === "todas" || p.categoria === categoriaAtual) &&
    p.nome.toLowerCase().includes(termo)
  );

  render(lista);
}

/* ========================= */
/* 🎯 FILTROS */
/* ========================= */

function gerarFiltros(){
  let container = el("filtros");
  if(!container) return;

  let lista = ["todas", ...new Set(produtos.map(p=>p.categoria))];

  container.innerHTML = lista.map(cat=>`
    <button class="${cat===categoriaAtual?'ativo':''}"
      onclick="filtrarCategoria('${cat}')">
      ${cat}
    </button>
  `).join("");
}

function filtrarCategoria(cat){
  categoriaAtual = cat;
  gerarFiltros();
  buscar();
}

/* ========================= */
/* 🛒 UI */
/* ========================= */

function toggleCarrinho(){
  el("carrinho")?.classList.toggle("ativo");
}
/* ========================= */
/* 🎯 BANNER ROTATIVO */
/* ========================= */

let bannerIndex = 0;

function rodarBanner(){
  const banners = document.querySelectorAll(".banner-slide");

  banners.forEach(b => b.classList.remove("ativo"));

  bannerIndex++;
  if(bannerIndex >= banners.length) bannerIndex = 0;

  banners[bannerIndex].classList.add("ativo");
}

// inicia automático
setInterval(rodarBanner, 3000);
function gerarMaisVendidos(){
  const container = el("listaMaisVendidos");
  if(!container) return;

  // 🔥 lógica simples (top 6 produtos)
  let maisVendidos = [...produtos]
    .sort(() => Math.random() - 0.5)
    .slice(0,12);

  container.innerHTML = maisVendidos.map(p=>`
    <div class="card-mini">
      <img src="${p.imagem || 'https://via.placeholder.com/100'}">
      <b>${p.nome}</b>
      <span>${formatar(p.preco)}</span>
      <button onclick="mais('${p.codigo}')">Adicionar</button>
    </div>
  `).join("");
}